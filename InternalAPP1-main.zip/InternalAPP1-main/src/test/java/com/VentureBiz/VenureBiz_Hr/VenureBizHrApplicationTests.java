package com.VentureBiz.VenureBiz_Hr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VenureBizHrApplicationTests {

	@Test
	void contextLoads() {
	}

}
