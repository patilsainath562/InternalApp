package com.VentureBiz.VenureBiz_Hr.model;

public enum Role {
    HR,
    EMPLOYEE
}
