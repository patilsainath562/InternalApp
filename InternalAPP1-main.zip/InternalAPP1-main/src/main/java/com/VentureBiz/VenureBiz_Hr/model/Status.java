package com.VentureBiz.VenureBiz_Hr.model;

public enum Status {
    ACTIVE,
    INACTIVE
    
}

